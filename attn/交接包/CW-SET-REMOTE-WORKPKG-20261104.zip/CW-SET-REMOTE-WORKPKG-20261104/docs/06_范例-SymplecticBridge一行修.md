# 06 · 修复范例 · SymplecticBridge 一行桥（家族 B 实战全记录）

> 本范例是我方 9.3 迁移中真实红点的完整修复记录（含我方初判的误判与更正）——供你校准自己的分诊手感。

## 现场文件

`UpReqSymplecticBridge.v` · 失败点 L304（`srs_renorm_rate` 证明体·第一 bullet）。

## 编译错误原文（9.3）

```
File ".\UpReqSymplecticBridge.v", line 304, characters 30-34:
Error:
In environment
c, s : Q
H1 : QleT 1 (c * c + s * s)
H4 : QleT' (c * c + s * s) 4
n : nat
Hq1 : 1 <= c * c + s * s
Hq4 : c * c + s * s <= 4
HDle :
  QleT' (c * c + s * s)
    (sp2_qnewton (c * c + s * s) 2 n * sp2_qnewton (c * c + s * s) 2 n)
The term "HDle" has type
  "QleT' (c * c + s * s) (sp2_qnewton … * sp2_qnewton …)"
```

## 误判与更正（分诊如实记录）

初判以为失败点是同函数第二 bullet 的 `exact (sp2_sqrt_rate_core …)`——**实际 log 的 L304 chars 30-34 指第一 bullet 的 `HDle` 四字符**。教训：**先读 log 的精确行列，再定位源行**——不信初读印象。

## 根因（一句话）

9.3 下 `sp2_qnewton_bnd` 的第三分量本就是 `QleT' D (x*x)` 形；第一 bullet 把目标转成 `Qle` 形后再 `exact HDle`（QleT' 形）就类型不匹配。9.1 下两形可互推故通过——**9.3 收紧了形间自动互推**。

## 修复（一行·证明体内）

```diff
--- UpReqSymplecticBridge.v L304（srs_renorm_rate·第一 bullet）
-    apply Qle_to_QleT'. exact HDle.
+    apply Qle_to_QleT'. exact (QleT'_to_Qle _ _ HDle).
```

## 验证

1. 单件编译：`coqc -native-compiler no -q -Q . "" UpReqSymplecticBridge.v` → **rc=0（6.5s）**；
2. 全出口件 `Print Assumptions` → 全 **Closed under the global context**；
3. 语句面断言：全文件 41 语句头（Definition 1/Theorem 20/Lemma 16/Fixpoint 4）修前修后逐字一致。

## 可复用的判定要点

1. `QleT'/Qle` 双形共存处，9.3 要求显式桥（`QleT'_to_Qle` / `Qle_to_QleT'`）；
2. 桥的方向 = 把**已拥有的形**桥到**目标形**（`exact (X_to_goal _ _ H)`）；
3. 桥引理在本模块依赖的接口件（UpReqSpec2x2 等）里现成——先查再写；
4. 修复前后跑 `Print Assumptions` 对比——桥不引入公理（纯构造互推）才算合格。
