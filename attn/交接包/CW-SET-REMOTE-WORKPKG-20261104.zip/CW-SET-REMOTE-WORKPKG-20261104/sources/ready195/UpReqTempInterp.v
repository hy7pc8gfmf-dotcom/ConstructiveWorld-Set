(* ============================================================ *)
(* UpReqTempInterp.v —— 温度全程插值件。使命：形式化温度两极间的显式插值：显式阈值    *)
(*   函数与误差上界 err_Δ(T) := e^{2Δ/T} − 1，全程单调骨架逐点钉住误差。依赖：           *)
(*   CW_ConstructiveWorld_219、UpTempWindow、AttnHardLimit218。构造性：全部 Qed、零假设  *)
(*   位（Print Assumptions 为 Closed）；语句全 Set 层；可提取。编译配方：9.1 直调         *)
(*   （toolchain env.sh 同源）、cpu_guard 绑核。                                         *)
(* ============================================================ *)
(* 两端点定理已在库：高温端 temp_window_T_infty（UpTempWindow）：∀eps>0 ∃T₂>0，T>T₂ ⟹     *)
(*   TV(w_T,U) ≤ eps，证明内见证为显式式；低温端 hard_attention_limit                      *)
(*   （AttnHardLimit218）：∀eps>0 ∃T₀>0，T<T₀ ⟹ TV(w_T,δ_m) ≤ eps，见证显式。本件使命：      *)
(*   把两端点的「存在阈值」升级为「显式函数+全程可控」——① 误差函数件 ti_err：err_Δ(T) :=    *)
(*   e^{2Δ/T} − 1（对任意 0<T 生效的显式温度-误差上界，即全程定量刻画的核心）；② 界关系     *)
(*   件 ti_err_antitone：0<T≤T' ⟹ err(T') ≤ err(T)（温度升 ⟹ 误差降，全程插值单调骨架）；      *)
(*   ③ 显式阈值定义件 ti_Th/ti_T0：两端点 T₀ 的独立提取；④ 主件 ti_temp_interp：∀Δ,eps>0，    *)
(*   见证 = 显式函数 ti_Th，封装「阈值完成 + 全程单调上界」两支（Set 层 sigT/And）。路线：   *)
(*   全部落 Real 层（与两端点同世界），复用 UpTempWindow 节外通用件（tw_ring_t2/             *)
(*   tw_ring_ddl/tw_exp_mono_le/tw_ring_one_eps_minus 族）与 AttnHardLimit218 节外乘法保序   *)
(*   件；使用 real_inv_pos_le_compat（倒数反序）、cauchy_real_exp_minus_one_pos/             *)
(*   cauchy_real_exp_mono、cw_log_exp_right/real_log_lt_mono/log_inv_one_thm。增量节：低温   *)
(*   端完成件 ti_hard_threshold。纪律：纯构造性；语句全 Set 层（sigT/And/real_lt/real_le）；  *)
(*   全部 Qed；零新假设位（Print Assumptions 须 Closed）。                                   *)
(* ============================================================ *)

Require Import S01_BaseRing.
Require Import S02_CauchyComplete.
Require Import S03_QExp.
Require Import S04_RealExpLogConv.
Require Import S05_AlignmentGRPO.
Require Import S06_DiffSamplingGibbs.
Require Import S07_RealSetoidExpLog.
Require Import S08_RealMainlineDPO.
Require Import S09_EntropyReal.
Require Import S10_KVQuantTrig.
Require Import S11_TP3B5.
Require Import S12_B5RecycleSF.
Require Import S13_NLiveAudit.
Require Import S14_B5BatchBlock.
Require Import S15_TailFEPUp.
Require Import UpTempWindow.
Require Import AttnHardLimit218.

(* ============================================================ *)
(* 1. 误差函数定义件：err_Δ(T) := e^{2Δ/T} − 1                   *)
(* ============================================================ *)

Definition ti_err (Delta T : Real) (Ht : real_lt real_zero T) : Real :=
  real_plus (cauchy_real_exp (real_mult (real_plus Delta Delta)
                           (real_inv_pos T Ht)))
            (real_opp real_one).

(* 基元：0 < Δ+Δ *)
Lemma ti_two_pos : forall Delta : Real,
  real_lt real_zero Delta -> real_lt real_zero (real_plus Delta Delta).
Proof.
  intros Delta HD.
  apply (real_eq_lt_lt real_zero (real_plus real_zero real_zero)
           (real_plus Delta Delta)).
  - apply real_eq_sym. apply real_plus_zero.
  - exact (real_lt_plus_compat real_zero Delta real_zero Delta HD HD).
Qed.

(* 误差函数正性：0<Δ, 0<T ⟹ 0 < err_Δ(T)（2Δ/T>0 + 指数差正件） *)
Lemma ti_err_pos : forall (Delta T : Real) (HD : real_lt real_zero Delta)
                            (Ht : real_lt real_zero T),
  real_lt real_zero (ti_err Delta T Ht).
Proof.
  intros Delta T HD Ht. unfold ti_err.
  apply (cauchy_real_exp_minus_one_pos
           (real_mult (real_plus Delta Delta) (real_inv_pos T Ht))).
  apply real_mult_pos_compat.
  - exact (ti_two_pos Delta HD).
  - apply real_inv_pos_pos.
Qed.

(* ============================================================ *)
(* 2. 界关系件：误差对温度的反单调（全程插值骨架）                *)
(*    0<Δ, 0<T≤T' ⟹ err(T') ≤ err(T)                            *)
(*    路线：倒数反序（real_inv_pos_le_compat）→ 乘法保序          *)
(*    （AttnHardLimit218 节外 real_le_mult_compat_l_aux）→        *)
(*    指数单调（tw_exp_mono_le）→ 加法保序。                      *)
(* ============================================================ *)

Lemma ti_err_antitone : forall (Delta T T' : Real)
  (HD : real_lt real_zero Delta) (Ht : real_lt real_zero T)
  (Ht' : real_lt real_zero T'),
  real_le T T' -> real_le (ti_err Delta T' Ht') (ti_err Delta T Ht).
Proof.
  intros Delta T T' HD Ht Ht' Hle. unfold ti_err.
  apply real_le_plus_compat.
  - apply tw_exp_mono_le.
    apply (real_le_mult_compat_l_aux _ _ _ (ti_two_pos Delta HD)).
    exact (real_inv_pos_le_compat T T' Ht Ht' Hle).
  - apply real_le_refl.
Qed.

(* ============================================================ *)
(* 3. 高温端显式阈值：cw_log(1+eps) 的正性与 Th 定义件            *)
(* ============================================================ *)

(* 1 < 1+eps（temp_window_T_infty 内 HU1 链的同构副本） *)
Lemma ti_one_eps_lt_one : forall eps : Real,
  real_lt real_zero eps -> real_lt real_one (real_plus real_one eps).
Proof.
  intros eps Heps.
  apply (real_eq_lt_lt real_one (real_plus real_one real_zero)
           (real_plus real_one eps)).
  - apply (real_eq_trans real_one (real_plus real_one real_zero)
             (real_plus real_zero real_one)).
    + apply real_eq_sym. apply real_plus_zero.
    + apply real_plus_comm.
  - apply (real_lt_eq_lt (real_plus real_zero real_one)
             (real_plus eps real_one) (real_plus real_one eps)).
    + exact (real_lt_plus_compat_lt_le real_zero eps real_one real_one
               Heps (real_le_refl real_one)).
    + apply real_plus_comm.
Qed.

(* 0 < 1+eps *)
Lemma ti_one_eps_pos : forall eps : Real,
  real_lt real_zero eps -> real_lt real_zero (real_plus real_one eps).
Proof.
  intros eps Heps.
  apply (real_lt_le_trans real_zero real_one (real_plus real_one eps)
           real_lt_zero_one).
  apply tw_le_plus_nonneg_r.
  apply tw_lt_le. exact Heps.
Qed.


Lemma ti_log_one_eps_pos : forall (eps : Real) (Heps : real_lt real_zero eps),
  real_lt real_zero (cw_log (real_plus real_one eps) (ti_one_eps_pos eps Heps)).
Proof.
  intros eps Heps.
  apply (real_eq_lt_lt real_zero (cw_log real_one real_lt_zero_one)
           (cw_log (real_plus real_one eps) (ti_one_eps_pos eps Heps))).
  - apply real_eq_sym. apply log_inv_one_thm.
  - exact (real_log_lt_mono real_one (real_plus real_one eps)
             real_lt_zero_one (ti_one_eps_pos eps Heps)
             (ti_one_eps_lt_one eps Heps)).
Qed.

(* 显式高温阈值定义件：Th(Δ,il) := 2Δ·il + 1（il=inv(cw_log(1+eps))） *)
Definition ti_Th (Delta il : Real) : Real :=
  real_plus (real_mult (real_plus Delta Delta) il) real_one.

(* 阈值正性：0<Δ, 0<il ⟹ 0 < Th（T₂ 正性链同构副本：0<1≤Th） *)
Lemma ti_Th_pos : forall (Delta il : Real) (HD : real_lt real_zero Delta)
                          (Hil : real_lt real_zero il),
  real_lt real_zero (ti_Th Delta il).
Proof.
  intros Delta il HD Hil. unfold ti_Th.
  assert (H2D : real_lt real_zero (real_plus Delta Delta))
    by exact (ti_two_pos Delta HD).
  assert (H2Dil : real_lt real_zero
                    (real_mult (real_plus Delta Delta) il))
    by exact (real_mult_pos_compat (real_plus Delta Delta) il H2D Hil).
  apply (real_lt_le_trans real_zero real_one
           (real_plus (real_mult (real_plus Delta Delta) il) real_one)
           real_lt_zero_one).
  apply (tw_le_eq_l (real_plus real_zero real_one)
           (real_plus (real_mult (real_plus Delta Delta) il) real_one)
           real_one).
  + apply real_le_plus_compat.
    * apply tw_lt_le. exact H2Dil.
    * apply real_le_refl.
  + apply (real_eq_trans real_one (real_plus real_one real_zero)
             (real_plus real_zero real_one)).
    * apply real_eq_sym. apply real_plus_zero.
    * apply real_plus_comm.
Qed.

(* ============================================================ *)
(* 4. 主件：温度全程插值（显式见证函数 + 双支刻画）                *)

(*    支1（阈值完成）：T > Th ⟹ err_Δ(T) ≤ eps                    *)
(*      （temp_window_T_infty 内 Th·L == 2Δ+L 代数链的同构副本）。 *)
(*    支2（全程单调）：0<T≤T' ⟹ err(T') ≤ err(T)——中段任意点      *)
(*      的误差被显式函数逐点钉住，两端点行为由此单调骨架插值。      *)
(* ============================================================ *)

Theorem ti_temp_interp :
  forall (Delta eps : Real),
    real_lt real_zero Delta ->
    real_lt real_zero eps ->
    sigT (fun Th => And (real_lt real_zero Th)
      (And (forall (T : Real) (Ht : real_lt real_zero T),
              real_lt Th T -> real_le (ti_err Delta T Ht) eps)
           (forall (T T' : Real) (Ht : real_lt real_zero T)
                                (Ht' : real_lt real_zero T'),
              real_le T T' ->
              real_le (ti_err Delta T' Ht') (ti_err Delta T Ht)))).
Proof.
  intros Delta eps HD Heps.
  pose (il := real_inv_pos (cw_log (real_plus real_one eps)
                              (ti_one_eps_pos eps Heps))
             (ti_log_one_eps_pos eps Heps)).
  pose (HL0 := ti_log_one_eps_pos eps Heps).
  exists (ti_Th Delta il). split.
  - apply (ti_Th_pos Delta il HD). apply real_inv_pos_pos.
  - split.
    + (* 支1：T > Th ⟹ err_Δ(T) ≤ eps（主定理代数链的同构副本） *)
      intros T Ht HT2T.
      pose (L := cw_log (real_plus real_one eps) (ti_one_eps_pos eps Heps)).
      pose (twoD := real_plus Delta Delta).
      assert (Ha : real_lt (real_mult (ti_Th Delta il) L) (real_mult T L))
        by exact (real_mult_lt_compat (ti_Th Delta il) T L HT2T HL0).
      assert (Hb : real_eq (real_mult (ti_Th Delta il) L)
                           (real_plus twoD L)).
      { apply (real_eq_trans
                 (real_mult (ti_Th Delta il) L)
                 (real_plus (real_mult twoD (real_mult L il)) L)
                 (real_plus twoD L)).
        - apply (real_eq_trans
                   (real_mult (ti_Th Delta il) L)
                   (real_mult L (ti_Th Delta il))
                   (real_plus (real_mult twoD (real_mult L il)) L)).
          + apply real_mult_comm.
          + exact (tw_ring_t2 Delta L il).
        - apply (RealSetoid.real_eq_plus_compat
                   (real_mult twoD (real_mult L il)) L twoD L).
          + apply (real_eq_trans (real_mult twoD (real_mult L il))
                     (real_mult twoD real_one) twoD).
            * apply (RealSetoid.real_eq_mult_compat twoD (real_mult L il)
                       twoD real_one (real_eq_refl twoD)
                       (real_inv_pos_correct L HL0)).
            * apply real_mult_one.
          + apply real_eq_refl. }
      assert (HinvT : real_lt real_zero (real_inv_pos T Ht))
        by apply real_inv_pos_pos.
      assert (Hc : real_lt (real_plus twoD L) (real_mult T L))
        by exact (real_eq_lt_lt (real_plus twoD L)
                    (real_mult (ti_Th Delta il) L) (real_mult T L)
                    (real_eq_sym _ _ Hb) Ha).
      assert (Hd : real_lt (real_mult (real_plus twoD L) (real_inv_pos T Ht))
                           (real_mult (real_mult T L) (real_inv_pos T Ht)))
        by exact (real_mult_lt_compat (real_plus twoD L) (real_mult T L)
                    (real_inv_pos T Ht) Hc HinvT).
      assert (He : real_eq (real_mult (real_mult T L) (real_inv_pos T Ht)) L).
      { apply (real_eq_trans
                 (real_mult (real_mult T L) (real_inv_pos T Ht))
                 (real_mult (real_mult T (real_inv_pos T Ht)) L) L).
        - apply tw_ring_abc_acb.
        - apply (real_eq_trans
                   (real_mult (real_mult T (real_inv_pos T Ht)) L)
                   (real_mult real_one L) L).
          + apply (RealSetoid.real_eq_mult_compat
                     (real_mult T (real_inv_pos T Ht)) L real_one L
                     (real_inv_pos_correct T Ht) (real_eq_refl L)).
          + apply tw_ring_mult_one_l. }
      assert (Hf : real_lt (real_mult (real_plus twoD L)
                                 (real_inv_pos T Ht)) L)
        by exact (real_lt_eq_lt (real_mult (real_plus twoD L)
                                      (real_inv_pos T Ht))
                   (real_mult (real_mult T L) (real_inv_pos T Ht)) L
                   Hd He).
      assert (HddT : real_eq (real_mult (real_plus twoD L)
                                   (real_inv_pos T Ht))
                             (real_plus (real_mult twoD (real_inv_pos T Ht))
                                (real_mult L (real_inv_pos T Ht))))
        by exact (tw_ring_ddl Delta L (real_inv_pos T Ht)).
      assert (HLiT : real_lt real_zero (real_mult L (real_inv_pos T Ht)))
        by (apply (real_mult_pos_compat L (real_inv_pos T Ht));
            [exact HL0 | exact HinvT]).
      assert (Hh : real_lt (real_plus (real_mult twoD (real_inv_pos T Ht))
                                (real_mult L (real_inv_pos T Ht))) L)
        by exact (real_eq_lt_lt
                    (real_plus (real_mult twoD (real_inv_pos T Ht))
                       (real_mult L (real_inv_pos T Ht)))
                    (real_mult (real_plus twoD L) (real_inv_pos T Ht)) L
                    (real_eq_sym _ _ HddT) Hf).
      assert (Hi : real_lt (real_mult twoD (real_inv_pos T Ht)) L).
      { apply (real_lt_trans (real_mult twoD (real_inv_pos T Ht))
                 (real_plus (real_mult twoD (real_inv_pos T Ht))
                    (real_mult L (real_inv_pos T Ht))) L).
        - apply tw_lt_plus_r_zero. exact HLiT.
        - exact Hh. }
      assert (Hj : real_lt (cauchy_real_exp
                              (real_mult twoD (real_inv_pos T Ht)))
                           (real_plus real_one eps))
        by exact (real_lt_eq_lt
                    (cauchy_real_exp (real_mult twoD (real_inv_pos T Ht)))
                    (cauchy_real_exp L) (real_plus real_one eps)
                    (cauchy_real_exp_mono
                       (real_mult twoD (real_inv_pos T Ht)) L Hi)
                    (cw_log_exp_right (real_plus real_one eps)
                       (ti_one_eps_pos eps Heps))).
      unfold ti_err.
      apply (real_le_trans
               (real_plus (cauchy_real_exp
                             (real_mult twoD (real_inv_pos T Ht)))
                          (real_opp real_one))
               (real_plus (real_plus real_one eps) (real_opp real_one))
               eps).
      * apply real_le_plus_compat; [exact (inl Hj) | apply real_le_refl].
      * apply tw_eq_le. exact (tw_ring_one_eps_minus eps).
    + (* 支2：全程单调（界关系件直连） *)
      intros T T' Ht Ht' Hle.
      exact (ti_err_antitone Delta T T' HD Ht Ht' Hle).
Qed.

(* ============================================================ *)
(* 5. 低温端显式阈值定义件（AttnHardLimit218 hard_attention_limit  *)

(*    阈值完成属性的重放列为升级路径，本件先交定义+正性）。        *)
(* ============================================================ *)

Definition ti_T0 (gamma il : Real) : Real := real_mult gamma il.

Lemma ti_T0_pos : forall (gamma il : Real) (Hg : real_lt real_zero gamma)
                          (Hil : real_lt real_zero il),
  real_lt real_zero (ti_T0 gamma il).
Proof.
  intros gamma il Hg Hil. unfold ti_T0.
  exact (real_mult_pos_compat gamma il Hg Hil).
Qed.

(* ============================================================ *)
(* 6. 端点世界连接引理：UpTempWindow 均匀 TV 距离被误差函数逐点主控     *)
(*    （tv_unif ≤ err_Δ(T)：温控全程刻画与端点件的核对线）          *)
(* ============================================================ *)

Lemma ti_tv_unif_le_err :
  forall (Tok : Set) (states : list Tok) (Hne : Not (Id states nil))
         (zz : Tok -> Real) (Delta : Real) (HD : real_lt real_zero Delta)
         (Hlo : forall x : Tok, real_le (real_opp Delta) (zz x))
         (Hhi : forall x : Tok, real_le (zz x) Delta)
         (T : Real) (Ht : real_lt real_zero T),
    real_le (tv_unif Tok states Hne zz T Ht)
            (ti_err Delta T Ht).
Proof.
  intros Tok states Hne zz Delta HD Hlo Hhi T Ht.
  exact (tv_unif_le Tok states Hne zz Delta HD Hlo Hhi T Ht).
Qed.

(* ============================================================ *)
(* 编目：本文件 10 证明件 + 3 定义件（ti_err / ti_Th / ti_T0）。   *)
(* 主件 ti_temp_interp 见证位 = 显式函数（非搜索），把高温端      *)
(* temp_window_T_infty 的 ∃T₂ 升级为命名函数件 ti_Th + 正性件     *)
(* ti_Th_pos + 完成件（主件支1）；全程插值语义 = 支2 单调骨架。   *)
(* ============================================================ *)

Print Assumptions ti_temp_interp.
Print Assumptions ti_err_antitone.
Print Assumptions ti_tv_unif_le_err.

(* ============================================================ *)
(* 7. 增量节（低温端完成）：ti_T0 阈值完成属性重放                *)
(*                                                              *)
(*    （AttnHardLimit218 hard_attention_limit Section 内对应证明体 *)
(*    的节外重放）。要点：                                        *)
(*    ① 节参全部具名显式——节参消失不对称以 About 检验为准：       *)
(*       tv_hard 6+2 参（无 gamma）/ tv_hard_le_decay_scale       *)
(*       11 参（要 gap_le 不要 gamma_pos）/ vocab_len_pos 7 参。  *)
(*    ② h_abs/decay_T 内机器（hsum_split/hsum_nonm_le 等          *)
(*       约 150 行）不重铸——直接使用节外导出件                    *)
(*       tv_hard_le_decay_scale（基座引擎在库）。                 *)
(*                                                              *)

From Stdlib Require Import List.

Theorem ti_hard_threshold :
  forall (Tok : Set) (vocab : list Tok) (Hne : Not (Id vocab nil))
         (Hdec : forall a b : Tok, Or (Id a b) (Not (Id a b)))
         (zz : Tok -> Real)
         (m : Tok) (Hmv : InT m vocab)
         (Hmc : @Id nat (count_token Tok Hdec m vocab) (Datatypes.S O))
         (gamma : Real) (Hg : real_lt real_zero gamma)
         (Hgap : forall x : Tok, Not (Id x m) ->
                   real_le (real_plus (zz x) gamma) (zz m))
         (eps : Real) (Heps : real_lt real_zero eps),
    sigT (fun T0 => And (real_lt real_zero T0)
      (forall (T : Real) (Ht : real_lt real_zero T), real_lt T T0 ->
        real_le (tv_hard Tok vocab Hne Hdec zz m T Ht) eps)).
Proof.
  intros Tok vocab Hne Hdec zz m Hmv Hmc gamma Hg Hgap eps Heps.
  set (N := length vocab).
  set (EN := real_of_nat N).
  set (M := real_mult EN (real_inv_pos eps Heps)).
  set (ylog := real_plus M real_one).
  assert (HM : real_lt real_zero M).
  { apply real_mult_pos_compat.
    - exact (vocab_len_pos Tok vocab Hne Hdec m Hmv Hmc).
    - apply real_inv_pos_pos. }
  assert (Hy : real_lt real_zero ylog).
  { apply (real_eq_lt_lt real_zero (real_plus real_zero real_zero) _).
    - apply real_eq_sym. apply real_plus_zero.
    - apply real_lt_plus_compat.
      + exact HM.
      + apply real_lt_zero_one. }
  assert (Hy1 : real_lt real_one ylog).
  { apply (real_eq_lt_lt real_one (real_plus real_zero real_one) ylog).
    - apply (real_eq_trans _ (real_plus real_one real_zero) _).
      + apply real_eq_sym. exact (real_plus_comm real_zero real_one).
      + exact (real_plus_zero real_one).
    - apply (real_lt_plus_compat_lt_le real_zero M real_one real_one HM
               (real_le_refl real_one)). }
  assert (HL : real_lt real_zero (cw_log ylog Hy)).
  { apply exp_reflects_lt.
    apply (real_eq_lt_lt (cauchy_real_exp real_zero) real_one
             (cauchy_real_exp (cw_log ylog Hy))).
    - exact cauchy_real_exp_zero.
    - apply (real_lt_eq_lt real_one ylog (cauchy_real_exp (cw_log ylog Hy))).
      + exact Hy1.
      + exact (real_eq_sym (cauchy_real_exp (cw_log ylog Hy)) ylog
                 (cw_log_exp_right ylog Hy)). }
  exists (ti_T0 gamma (real_inv_pos (cw_log ylog Hy) HL)). split.
  - apply (ti_T0_pos gamma (real_inv_pos (cw_log ylog Hy) HL) Hg).
    apply real_inv_pos_pos.
  - intros T Ht Hlt.
    set (invT := real_inv_pos T Ht).
    assert (HinvT : real_lt real_zero invT) by apply real_inv_pos_pos.
    set (a := real_mult invT gamma).
    (* 步1：T·L < γ *)
    assert (Hs1 : real_lt (real_mult T (cw_log ylog Hy)) gamma).
    { apply (real_lt_eq_lt (real_mult T (cw_log ylog Hy))
               (real_mult (real_mult gamma (real_inv_pos (cw_log ylog Hy) HL))
                  (cw_log ylog Hy)) gamma).
      - apply (real_mult_lt_compat T
                  (real_mult gamma (real_inv_pos (cw_log ylog Hy) HL))
                  (cw_log ylog Hy) Hlt HL).
      - apply (real_eq_trans _
                 (real_mult gamma
                    (real_mult (real_inv_pos (cw_log ylog Hy) HL)
                               (cw_log ylog Hy))) _).
        + apply real_eq_sym. apply real_mult_assoc.
        + apply (real_eq_trans _
                   (real_mult gamma
                      (real_mult (cw_log ylog Hy)
                         (real_inv_pos (cw_log ylog Hy) HL))) _).
          * apply (RealSetoid.real_eq_mult_compat gamma
                     (real_mult (real_inv_pos (cw_log ylog Hy) HL)
                                (cw_log ylog Hy))
                     gamma
                     (real_mult (cw_log ylog Hy)
                                (real_inv_pos (cw_log ylog Hy) HL))).
            -- apply real_eq_refl.
            -- apply real_mult_comm.
          * apply (real_eq_trans _ (real_mult gamma real_one) _).
            -- apply (RealSetoid.real_eq_mult_compat gamma
                        (real_mult (cw_log ylog Hy)
                           (real_inv_pos (cw_log ylog Hy) HL)) gamma real_one).
               ++ apply real_eq_refl.
               ++ apply (real_inv_pos_correct (cw_log ylog Hy) HL).
            -- apply real_mult_one. }
    (* 步2：L < γ/T *)
    assert (Hs2 : real_lt (cw_log ylog Hy) a).
    { assert (Hmul : real_lt (real_mult invT (real_mult T (cw_log ylog Hy)))
                             (real_mult invT gamma))
        by (apply (real_mult_lt_compat_l _ _ invT Hs1 HinvT)).
      apply (real_lt_eq_lt (cw_log ylog Hy) (real_mult invT gamma) a).
      + apply (real_eq_lt_lt (cw_log ylog Hy)
                 (real_mult invT (real_mult T (cw_log ylog Hy)))
                 (real_mult invT gamma)).
        * apply real_eq_sym.
          exact (real_eq_trans _ _ _
                   (real_eq_trans _ _ _
                     (real_eq_trans _ _ _
                       (real_mult_assoc invT T (cw_log ylog Hy))
                       (RealSetoid.real_eq_mult_compat
                          (real_mult invT T) (cw_log ylog Hy)
                          (real_mult T invT) (cw_log ylog Hy)
                          (real_mult_comm invT T)
                          (real_eq_refl (cw_log ylog Hy))))
                     (RealSetoid.real_eq_mult_compat
                        (real_mult T invT) (cw_log ylog Hy)
                        real_one (cw_log ylog Hy)
                        (real_inv_pos_correct T Ht)
                        (real_eq_refl (cw_log ylog Hy))))
                   (real_eq_trans _ _ _
                     (real_mult_comm real_one (cw_log ylog Hy))
                     (real_mult_one (cw_log ylog Hy)))).
        * exact Hmul.
      + apply real_eq_refl. }
    (* 步3：M ≤ e^{γ/T} *)
    assert (Hs3 : real_le M (cauchy_real_exp a)).
    { apply (real_le_trans _ (cauchy_real_exp (cw_log ylog Hy)) _).
      - apply (RealSetoid.real_le_id_r M ylog
                 (cauchy_real_exp (cw_log ylog Hy))).
        + exact (real_eq_sym (cauchy_real_exp (cw_log ylog Hy)) ylog
                   (cw_log_exp_right ylog Hy)).
        + apply real_le_plus_nonneg_r_aux.
          apply real_le_from_lt_aux. apply real_lt_zero_one.
      - apply real_exp_le_mono. exact (real_le_from_lt_aux _ _ Hs2). }
    (* 步4：N ≤ eps·e^{γ/T} *)
    assert (Hs4 : real_le EN (real_mult eps (cauchy_real_exp a))).
    { apply (RealSetoid.real_le_id_l EN (real_mult eps M) _).
      - exact (real_eq_sym _ _
          (real_eq_trans _ _ _
            (real_mult_assoc eps EN (real_inv_pos eps Heps))
            (real_eq_trans _ _ _
              (RealSetoid.real_eq_mult_compat
                 (real_mult eps EN) (real_inv_pos eps Heps)
                 (real_mult EN eps) (real_inv_pos eps Heps)
                 (real_mult_comm eps EN)
                 (real_eq_refl (real_inv_pos eps Heps)))
              (real_eq_trans _ _ _
                (real_eq_sym _ _ (real_mult_assoc EN eps (real_inv_pos eps Heps)))
                (real_eq_trans _ _ _
                  (RealSetoid.real_eq_mult_compat
                     EN (real_mult eps (real_inv_pos eps Heps))
                     EN real_one
                     (real_eq_refl EN) (real_inv_pos_correct eps Heps))
                  (real_mult_one EN)))))).
      - apply (real_le_mult_compat_l_aux M (cauchy_real_exp a) eps
                 Heps Hs3). }
    (* 步5：e^{−γ/T}·N ≤ eps *)
    assert (Hs5 : real_le
                    (real_mult (cauchy_real_exp (real_opp a)) EN) eps).
    { apply (RealSetoid.real_le_id_r
               (real_mult (cauchy_real_exp (real_opp a)) EN)
               (real_mult (cauchy_real_exp (real_opp a))
                  (real_mult eps (cauchy_real_exp a))) eps).
      - apply (real_eq_trans _
                 (real_mult (cauchy_real_exp (real_opp a))
                            (real_mult (cauchy_real_exp a) eps)) _).
        + apply (RealSetoid.real_eq_mult_compat
                    (cauchy_real_exp (real_opp a))
                    (real_mult eps (cauchy_real_exp a))
                    (cauchy_real_exp (real_opp a))
                    (real_mult (cauchy_real_exp a) eps)).
          * apply real_eq_refl.
          * apply real_mult_comm.
        + apply (real_eq_trans _
                     (real_mult
                        (real_mult (cauchy_real_exp (real_opp a))
                                   (cauchy_real_exp a))
                        eps) _).
          * apply real_mult_assoc.
          * apply (real_eq_trans _ (real_mult real_one eps) _).
            -- apply (RealSetoid.real_eq_mult_compat
                        (real_mult (cauchy_real_exp (real_opp a))
                                   (cauchy_real_exp a))
                        eps
                        real_one eps).
               ++ apply exp_mult_opp_l_aux.
               ++ apply real_eq_refl.
            -- apply (real_eq_trans _ (real_mult eps real_one) _).
               ++ apply real_mult_comm.
               ++ apply real_mult_one.
      - apply (real_le_mult_compat_l_aux EN
                 (real_mult eps (cauchy_real_exp a))
                 (cauchy_real_exp (real_opp a))).
        + apply cauchy_real_exp_pos.
        + exact Hs4. }
    (* 完成：tv_hard ≤ N·e^{−γ/T} ≤ e^{−γ/T}·N ≤ eps *)
    apply (real_le_trans _
             (real_mult (real_of_nat N)
                        (decay_T gamma T Ht)) _).
    + exact (tv_hard_le_decay_scale Tok vocab Hne Hdec zz m Hmv Hmc
               gamma Hgap T Ht).
    + apply (real_le_trans _
               (real_mult (cauchy_real_exp (real_opp a)) (real_of_nat N)) _).
      * apply (RealSetoid.real_eq_le). apply real_mult_comm.
      * exact Hs5.
Qed.

Print Assumptions ti_hard_threshold.

(* 编目补记：本文件证明件 10 → 11（新增 ti_hard_threshold），
   定义件 3 不变（ti_err / ti_Th / ti_T0）。低温端 hard_attention_limit
   的 ∃T₀ 见证升级为命名函数件 ti_T0 + 正性件 ti_T0_pos + 完成件
   ti_hard_threshold；至此温度两极（高温 ti_temp_interp / 低温
   ti_hard_threshold）均具「显式阈值 + 全程定量」形态。 *)
