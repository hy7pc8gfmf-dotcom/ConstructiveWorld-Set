# 任务书 · 批次 1 · Main→Set 洗涤劳动（195 件即洗池·CW-Set 远程席位）

> **主任务**：将我方大库（Main）的模块**清洗为 Set 载体版本并纳入 Set 库**（跨仓洗涤·产线已实证 38+ 批次同款流水线·你接力）。随包源料 195 件（`sources\ready195\`·依赖闭合于 Set 面·即洗即用）。**裁决与安全边界见 05 文档**（禁直 push main·禁改 CI/基线·PR 制）。

## 一、每件洗涤标准作业（SOP·逐件走七步）

### 步 1 · 取料与依赖勘形

- 取 `sources\ready195\<模块>.v`（Main 侧原文）；
- 查 `_deps_manifest.json` 该件 deps 清单——**全部在 Set 面**（已核·若你发现清单外依赖＝超出池判定·停手报告）；
- 在你的 Set clone 里确认 deps 的 `.vo` 可用（首次需增量编译 deps——见 §四首次环境构建）。

### 步 2 · Prop 面改写（ch1/ch2 → 0）

按 `docs\01` 律一配方表与 `docs\02` 处方表：
- `: Prop` 语句 → Set 载体（`Id bool`/`And`/`sigT`/决策 Id 形）；
- **禁类型级 match 定 Set**（用布尔函数＋`@Id bool`）；
- 普查自检：`gate6_statement_census.py --tree ConstructiveWorld_Live --text` → 该件 ch1=ch2=ch3=0。

### 步 3 · 9.3 适配

按 `docs\04` 五家族处方：双 `Proof.`（含同行带策略形·宽松扫描）/QleT'/Qle 桥/自引用 Require/缺依赖级联（缺依赖＝超出池判定·停手报告）/magic 四亚型。

### 步 4 · 落位注册

- 洗好的件放 `ConstructiveWorld_Live\<模块>.v`；
- `order.txt` 与 `_CoqProject` 各加一行（位置：依赖之后·拓扑序）——**漏入册＝coverage 红**。

### 步 5 · 自检三连

```
gate4 --tree ConstructiveWorld_Live        → 无红
gate6 --gate --baseline tools\gate6_baseline.json → 无增长
gate7 单件探针（Separate Extraction 全语句名）→ magic=0/0 · missing=0
单件 9.3 编译 rc=0 ＋ Print Assumptions Closed
```

### 步 6 · 批次提交

- 3-5 件一批（单 commit·`wash(batch1): <家族> <件数>件`）·推你侧分支→开 PR（模板见 05）。

### 步 7 · 我方复核与裁决

五门复跑＋9.3 探针＋语句面断言→合并/打回（附意见）。

## 二、批次 1 指派

- **池**：`sources\ready195\`（195 件·`_deps_manifest.json` 每件 deps 与 dep_count）；
- **选件规则**：dep_count 升序先行（小件热手·大件殿后）；单批次 3-5 件；
- **禁选**：批内发现 deps 实际不在 Set 面（清单外依赖）→ 该件移出批次·登记报告（池判定如有个例误差以实编译为准）；
- **提交面**：只 add 本批次 `.v` ＋ order.txt/`_CoqProject` 的对应行——**禁夹带**其他文件。

## 三、验收（每件）

| # | 判据 | 工具 |
|---|---|---|
| 1 | gate6 该件三通道=0 | census --text 逐件 |
| 2 | gate7 该件 magic=0/0·语句名无缺失 | gate7_extract_run 或单件驱动 |
| 3 | 9.3 编译 rc=0 | coqc 9.3 |
| 4 | 语句面内容保持（Main 原文的定理/引理名与逻辑内容对应·载体形合法） | PR 描述附改写对照 |
| 5 | Print Assumptions Closed | 件内出口 |

## 四、如实边界

- **Prop 清洗滚动岗现状**：Set 面已零存量（census 快照随包）——本批次 1 的"清洗"发生在**来自 Main 的源件**上（Main 件带 Prop 面·入 Set 面前必须洗零）；
- Main 侧未推/在飞件不在此池（动态面·以我方批次指派为准）；
- 洗涤中若发现 Main 原文本身逻辑可疑（不只是形）→ 停手·PR 描述申报·不硬洗。

## 五、交付

- PR（你侧分支→main）·模板见 05；
- 批次报告（清单/家族/自检记录）入 PR 描述；
- 我方 CI 席 24h 内五门复跑回执→裁决合并/打回。
