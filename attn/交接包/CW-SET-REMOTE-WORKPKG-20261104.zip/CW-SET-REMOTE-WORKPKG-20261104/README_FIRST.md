# README_FIRST · 远程洗涤席位工作包（CW-Set·Main→Set 洗涤劳动·20261104 版）

> **致接包的智能体/同事**：本包是「ConstructiveWorld-Set 仓库·Main→Set 模块洗涤远程席位」的完整工作包。按本文件顺序执行即自动完成环境装配、任务理解与批次 1 开工。核心劳动＝**把我方大库（Main）的模块清洗成 Set 载体版本并纳入 Set 库**（我方产线已实证 38+ 批次的同款流水线·你接力）。包内已含**洗涤积压中的 195 件即洗件源料**（依赖闭合于 Set 面·零外溢·逐件已核）。

## 你将成为什么席位

**CW-Set 远程洗涤与认证席位**，三类劳动：
1. **洗涤劳动（主任务）**：取 Main 模块源料 → Prop 面 Set 载体改写（ch1/ch2→0）→ 9.3 适配（双 Proof/QleT' 桥等五家族处方）→ 入 Set 面注册 → 自检三连 → PR → 我方五门复核＋9.3 探针 → 裁决合并；
2. **认证劳动**：本地复跑五门与全树核验，制备认证批次报告；
3. **Prop 清洗（滚动岗）**：新进件 gate6 三通道非零即洗（现状如实告知：Set 面已 100% Set 载·325 件/12,377 名·ch1=ch2=ch3=0——滚动岗为校验性质）。

提交流：**你侧分支 → push 你侧 → PR 到我方 main → 我方复跑裁决合并**。你永远不直接 push 我方 main。

## 五步自装配（顺序执行·预计 1-2h＋工具链下载）

### 第 1 步：释放本包（镜像我方拓扑）

释放到 **`D:\ComplexAnalysis\attn\`** 下（保持包内目录结构·`D:\ComplexAnalysis` 不存在则创建）。你的 Set 仓库 clone 到 **`D:\ComplexAnalysis\ConstructiveWorld-Set\`**（与我方盘面路径一致——所有工具命令与任务书路径按此书写）。

### 第 2 步：读规约（不可跳过）

`docs\01_红线律与规约.md`（五铁律＋判例表）→ `docs\02_三闸与五门自检手册.md`（三闸自检·Prop→Set 改写配方表）→ `docs\00_目录拓扑与镜像约定.md`。

### 第 3 步：装配 Rocq 9.3 工具链

按 `docs\03_Rocq93环境装配手册.md`（opam 源码构建·三大坑实录·魔数表·兼容名承重件说明）。验证：`rocq -v`＝9.3.0。

### 第 4 步：自己的账号拉取 Set 仓库

```bash
cd D:\ && mkdir ComplexAnalysis 2>nul & cd ComplexAnalysis
git clone https://github.com/hy7pc8gfmf-dotcom/ConstructiveWorld-Set.git ConstructiveWorld-Set
cd ConstructiveWorld-Set && git log --oneline -1   # f26bb63 或更新
```

- 仓库为私有：需你账号被我方授权为协作者（发包时完成）；无权限先索权；
- **Main 大库不需要 clone**：批次 1 的全部源料在 `sources\ready195\`（195 件·依赖闭合于 Set 面·逐件已核）。Main 的在线浏览用 GitHub 网页即可（可选）。

### 第 5 步：自检三连（环境就绪证明）

```bash
cd D:\ComplexAnalysis\ConstructiveWorld-Set
python scripts\gates\gate6_statement_census.py --tree ConstructiveWorld_Live --text
# 预期：ch1=0 ch2=0（面已零 Prop——这是你要守住的底色）
D:\<你的9.3>\coqc.exe -native-compiler no -q -Q ConstructiveWorld_Live "" ConstructiveWorld_Live\S01_BaseRing.v && echo OK
```

## 包内导航

| 路径 | 内容 |
|---|---|
| `docs\00-06` | 拓扑约定/红线律/三闸手册/9.3 装配/红点五家族与处方/提交审核流程/SymplecticBridge 修复范例 |
| `tasks\` | 任务书（批次 1·洗涤劳动 SOP 与验收） |
| `sources\ready195\` | **195 件即洗件源料**（Main 侧 .v 原文·依赖闭合于 Set 面·逐件已核）＋`_deps_manifest.json`（每件依赖清单） |
| `tools\` | gate1/2/4/5/6/7 五门工具＋基线（与我方 CI 同版） |
| `refs\` | 普查快照（面已零 Prop 的证据）＋`backlog-20261104.json`（681 件积压分类账：195 即洗＋485 待依赖链） |

## 三条绝对禁令（违者包退回）

1. **禁直接 push 我方 main / force-push**（一切走你侧分支＋PR·我方裁决合并）；
2. **禁引入 Prop 面/公理/Admitted/Obj.magic**（born-clean 零容忍·三闸机判）；
3. **禁引用/使用我方任何凭据**（netrc/token）——一切 git 操作用你自己的账号。

## 两处已知边界（如实）

- 沙箱面与 origin 面差 1 件（`Local/LW0LeibSeparation.v`）——批次 1 不涉及；切基首炉 CI 现编；
- Main 侧 4 件孤儿（依赖全仓不存在的 UpAblP6_*/FepIdConsume/fka_weak_triangle_ref/UpReqPadeBetaPos 消费者）＝我方产线欠账·**不在你的洗涤池**（已从 195 排除）。
